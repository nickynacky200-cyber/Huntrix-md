const settings = {
  packname: 'HUNTRIX MD',
  author: '‎',
  botName: "HUNTRIX MD",
  botOwner: 'Redline', // Your name
  ownerNumber: '2349051906943', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "1.0.0",
  updateZipUrl: "https://github.com/mruniquehacker/Knightbot-MD/archive/refs/heads/main.zip",
};

module.exports = settings;
